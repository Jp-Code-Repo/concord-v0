<?php

use App\Http\Controllers\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\GrantController;
use App\Http\Controllers\UserManagementController;

// Final URLs are /api/iam/... (Laravel adds the /api prefix).
Route::prefix('iam')->group(function () {
    Route::post('login', [AuthController::class, 'login'])->middleware('throttle:10,1');

    Route::middleware('session.auth')->group(function () {
        Route::post('logout', [AuthController::class, 'logout']);
        Route::get('me', [AuthController::class, 'me']);
        // Called by the edge's auth_request only (the edge hides it from the outside).
        Route::get('verify', [AuthController::class, 'verify']);

        Route::post(
            '/offices/{office}/memberships/{membership}/grants',
            [GrantController::class, 'store']
        );

        Route::post(
            '/offices/{office}/memberships/{membership}/grants/{grant}/revoke',
            [GrantController::class, 'revoke']
        );

        Route::post(
            '/users/{user}/disable',
            [UserManagementController::class, 'disable']
        );
    });

    // Self-test for edge authentication: only answers when the edge vouched for the caller.
    Route::get('edge-check', function (Request $request) {
        $userId = $request->server('CONCORD_USER_ID');

        return $userId
            ? response()->json(['user_id' => $userId])
            : response()->json(['message' => 'No identity from the edge.'], 401);
    });
});
