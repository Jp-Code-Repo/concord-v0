# Concord Frontend

## Scope and Status

**Document status:** Working requirements and backlog  
**Source:** Frontend requirements extracted from the Concord IAM working document and implementation context. This is not yet a complete UI specification.

The frontend presents Concord workflows and consumes platform/module APIs. It must reflect the identity boundary defined in [`IAM.md`](IAM.md), while HRIS workflows and ownership are documented in [`HRIS.md`](HRIS.md).

## 1. Employee Onboarding

Planned experience:

- Employee onboarding landing page.
- Step navigation through onboarding.
- Personal Data Sheet (PDS) forms organized by category or group.
- Submission confirmation.
- Onboarding status display.
- Pending-review status and HR feedback display.

The exact step flow, status definitions, review outcomes, and exception handling remain to be designed with HRIS requirements.

## 2. Administrator Experience

Planned experience:

- Administrator dashboard.
- User Management module.
- User listing and details.
- Create and manage user accounts.
- Account-status management.
- Student CSV import interface.
- CSV validation results and import error reporting.

User Management must accommodate student, parent/guardian, and visitor account creation outside normal HR-led employee provisioning.

## 3. Parent and Guardian Management

Deferred frontend requirements:

- Parent/guardian relationship management.
- Parent-to-student linking workflow.
- Review and management of existing relationships.

Do not build these interfaces until the relationship matching and management process is defined. Importing guardian information from student CSV files must not automatically create parent accounts or relationships.

## 4. Frontend Behavior Requiring Specification

- What each person type sees after login.
- How account status is communicated in the login experience.
- Administrator dashboard content.
- Whether students, parents, and visitors receive different dashboard layouts.
- How onboarding restrictions affect module access.
- How roles and permissions control navigation and page access.
- How a person manages or switches among multiple institutional types/capacities. **The user will design this workflow; do not invent it.**

## 5. Implemented Frontend Integration

The latest recorded IAM implementation pass updated the frontend profile to read identity through `user.person`, removing placeholder personal and employment data that IAM does not own. Existing preference controls were connected to persistence:

- Concord-wide personal preferences are persisted through the `people` identity boundary.
- Session-warning settings are persisted through the `users` account boundary.

These notes confirm the integration work recorded in the implementation history. They do not claim that the complete onboarding, Administrator dashboard, CSV import, or parent/guardian relationship interfaces have been implemented.

## 6. Maintenance Rules

- Keep frontend requirements and user-facing behavior here.
- Record completed frontend changes in chronological order in [`IMPLEMENTATION_LOG.md`](IMPLEMENTATION_LOG.md).
- Keep proposed UI behavior separate from verified implementation.
- Ask the user before making unresolved product or workflow decisions.
