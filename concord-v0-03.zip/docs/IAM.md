# Concord IAM

## Identity Domain: Requirements, Decisions, and Implementation Status

**Document status:** Working specification, with implementation progress updated through 2026-10-24  
**Scope:** Identity, account provisioning, authentication, account lifecycle, and IAM-owned access foundation  
**Authority:** This document records IAM requirements and decisions. Chronological implementation history belongs in [`IMPLEMENTATION_LOG.md`](IMPLEMENTATION_LOG.md).

## 1. Architectural Direction

Concord's Identity and Access Management (IAM) is the platform's identity and access foundation. Responsibilities are documented separately under:

1. Identity
2. Authentication
3. Roles
4. Permissions and authorization
5. Governance and supporting concerns

Laravel Gates, Policies, and Spatie Laravel Permission remain potential authorization tools. Their final configuration and responsibilities have not been decided. Approved requirements take precedence over legacy implementation details.

**Boundary principle:** IAM owns Concord identity and account/authentication concerns. Module-specific business data belongs to the responsible module or service. HRIS and frontend requirements are maintained in [`HRIS.md`](HRIS.md) and [`FRONTEND.md`](FRONTEND.md).

## 2. Identity Requirements

### 2.1 Person types and capacities

Concord is intended to support:

- Employees
- Students
- Parents or guardians
- Visitors

These are non-exclusive person types, not mutually exclusive account classes. One person may hold multiple institutional capacities simultaneously, for example teacher and parent, staff and parent, teacher and department head, or principal and office-in-charge.

The database implementation supports `employee`, `student`, `parent_guardian`, and `visitor` person types.

### 2.2 Basic identity information

Names are stored as separate components.

- **Employee:** first name, middle name, last name, suffix, gender, email.
- **Student:** student number, first name, middle name, last name, suffix.
- **Parent/guardian:** first name, middle name, last name, suffix, gender, email.
- **Visitor:** first name, middle name, last name, suffix, gender, email.

Date of birth is excluded from the basic IAM identity record. Detailed employee personal information belongs in HRIS. Detailed student information remains the responsibility of the student information system. Exact validation rules and optionality for some fields remain open.

### 2.3 Person and account boundary

**Approved decision: separate `people` and `users`.** Each table has its own ULID primary key. `users.person_id` references `people.id` and is unique, enforcing at most one human account per person through this relationship.

- `people` stores basic identity fields and Concord-wide personal preferences.
- `users` stores username, password hash, account status, authentication/session settings, and account-level administration metadata.
- A person may exist before an account is provisioned.
- Administrator-created accounts create the person and linked user as one operation.
- HRIS supplies basic identity data for an actual employee through its onboarding/provisioning workflow; IAM creates or resolves the person and provisions the linked account.
- Personal preferences belong to `people`, so they remain with the person if an account is deactivated or replaced.
- Credentials, account status, and authentication/session settings remain on `users`.
- The user will design the frontend workflow for managing or switching among multiple types/capacities. Do not invent or implement that interaction flow before receiving the user's design.

### 2.4 Employee classifications and assignments

Staff and Teacher are the currently identified primary employee classifications. A primary classification must be distinguishable from institutional position and additional responsibility. Examples include temporary teaching loads, Department Head appointments, Principal, Registrar, Business Office Manager, HR Head, and office-in-charge assignments.

Assignment history must retain start/end history and identify currently active assignments. Ending an assignment must not erase history, and historical assignments must not automatically grant current authority. Detailed employment and assignment data is an HRIS responsibility; see [`HRIS.md`](HRIS.md).

### 2.5 Employee history

Employee records and relevant employment history must remain available after an employee leaves the institution for institutional analytics and reporting. Employment status and Concord account status are separate concerns.

### 2.6 Account status

The current implementation supports:

- **Active:** enabled for access, subject to authorization.
- **Deactivated:** inactive, such as after employment ends.
- **Disabled:** blocked by an administrative restriction, such as suspension.

Both deactivation and disabling revoke active sessions. Formal reactivation and approval transitions remain to be finalized. A disabled account must remain inaccessible until the required formal reactivation process is completed. Existing identity and historical records must be preserved.

### 2.7 Student identity and enrollment history

Student identity is separate from school-year-specific enrollment. Student number is required and unique for student records. Enrollment history retains school year, grade level, section, and enrollment status. Candidate statuses include enrolled, promoted, retained, transferred out, and stopped; exact definitions and transitions must be confirmed against institutional terminology.

Guardian information supplied by imports may be retained as raw enrollment/import metadata. It must not automatically create parent accounts or parent-student relationships. The earlier idea of retaining only the current school year's information was withdrawn; enrollment history must be preserved across school years.

## 3. Administrator and User Provisioning

### 3.1 Administrator

The envisioned `ADMINISTRATOR` is the highest-authority entity in Concord, with only one intended to exist. It oversees platform-level functions, including IAM and user management, and may have HRIS-related administration responsibilities.

Its technical representation remains undecided: special account classification, platform-level role, or another identity concept. Account recovery, continuity, and consequences of losing access to the unique Administrator account must be addressed before production deployment.

### 3.2 User Management

Concord will provide a User Management module for Administrator-managed accounts outside normal provisioning workflows. It must support creating/managing accounts for students, parents/guardians, and visitors. Employee onboarding follows a separate HR-led process.

### 3.3 Student CSV import

The existing student information system is the source of student records. Concord will support importing basic student information, potentially via CSV, including student number, student name components, parent/guardian names and contact numbers, school year, grade level, and section.

Import validation, duplicate detection, update behavior, missing-student handling, and exact CSV columns remain open. Importing guardian data must not automatically create accounts or relationships.

### 3.4 Parent/guardian and visitor accounts

Parent and guardian accounts are initially created independently by the Administrator. A student may have multiple parents/guardians, and one parent/guardian may be associated with multiple students. Matching and relationship management are deferred until a separate process is designed.

The Administrator manually creates visitor accounts through User Management, which must include `Visitor` as an available category. Automated visitor registration, expiration, and visitor-specific access policies are outside the currently established scope.

## 4. Authentication and Implemented Foundation

The implementation includes login and identity retrieval, account status checks, session revocation, identity-linked profile data, preference persistence, and account management endpoints. Detailed implementation chronology and verification evidence are maintained in [`IMPLEMENTATION_LOG.md`](IMPLEMENTATION_LOG.md).

Current verified behavior from the latest recorded test run:

- Login and `/me` identity retrieval are covered.
- Unknown-user and wrong-password responses are tested for equivalent behavior.
- Disabled accounts cannot log in.
- Session revocation is effective.
- Identity headers are verified.
- The edge rejects callers not vouched for.
- IT-admin account disablement revokes sessions; non-admin access is denied; attempting to disable an already disabled account returns a conflict.

## 5. Access and Authorization Status

`is_it_admin` remains a transitional implementation detail while roles and permissions are undecided. The current `AccessService` is a minimal compatibility implementation only: it returns `all_access` for an IT admin and empty `apps` and `offices` collections, with cache invalidation support. It is **not** the final permissions architecture and must not be treated as an approved long-term authorization design.

Do not restore legacy authorization queries that depend on removed tables. The final role/permission model, use of Laravel Gates/Policies and/or Spatie Permission, and Administrator representation require explicit decisions before implementation.

## 6. Current Implementation Status (as of 2026-10-24)

### Implemented

- `people` table with ULID identity, split name fields, optional gender/email, and JSON preferences.
- Required unique `users.person_id` relationship.
- Migration of user display identity into `people` and removal of duplicate `email`/`display_name` fields from `users`.
- Non-exclusive person types for employee, student, parent/guardian, and visitor.
- Student identity and school-year enrollment history tables.
- Administrator account creation that creates a person and user atomically and returns the initial password once.
- Separate person creation and service-level account provisioning for HRIS-supplied identities.
- Authentication payload and frontend profile updated to read identity through `user.person`; placeholder personal/employment data not owned by IAM removed.
- Self-service personal preferences persisted on `people`; session-warning settings persisted on `users`.
- Administrator user listing, account deactivation, account disabling, and student enrollment history endpoints.
- Seeders and feature tests updated for person-linked accounts and sample identity categories.
- Audit log insert aligned with the current schema, which has no `office_id`.
- JSON assertions adjusted to decode response JSON rather than depend on serialization whitespace.
- Legacy schema tables from the previous access model removed in the fresh identity-foundation schema. Do not rerun destructive migrations casually; inspect current environment and migration state first.

### Verification

Latest recorded Docker-based PHPUnit run: **16 tests passed, 98 assertions**. The suite included authentication, identity foundation, user creation, user management, and the example unit test. See `IMPLEMENTATION_LOG.md` for the test groups and limitations.

This supersedes the earlier verification note in the original working document that PHPUnit could not start because of local PHP extensions/database drivers. That note described an earlier environment attempt, not the latest Docker-based result. Other historical environment limitations (including a frontend production build issue involving an archived Rolldown native binding) should not be mistaken for a current verified failure unless reproduced.

## 7. Outstanding Decisions

These items are **not finalized** and must not be silently decided during implementation:

- Whether `ADMINISTRATOR` is a special account type, platform-level role, or another concept.
- Administrator account recovery and continuity.
- Exact optionality and validation for basic identity fields.
- Formal account-status transitions and reactivation approval.
- Exact CSV format and import/update behavior.
- Parent-student relationship matching and management.
- Role and permission ownership and implementation using Laravel and Spatie.
- Authorization behavior for frontend navigation and each person type.
- HRIS integration and onboarding automation.
- The frontend workflow for managing/switching among a person's multiple types/capacities. This is reserved for the user's design.

## 8. Document Maintenance Rules

- Keep IAM requirements and decisions here; put frontend behavior in `FRONTEND.md` and HRIS requirements in `HRIS.md`.
- Record verified completed work chronologically in `IMPLEMENTATION_LOG.md`; do not use the log as a substitute for current requirements.
- When a requirement changes, state whether the earlier requirement was replaced, withdrawn, or retained.
- Preserve institutional context and the user's explanations when refining requirements.
- Clearly label proposals and transitional compatibility code. Do not describe them as final decisions.
