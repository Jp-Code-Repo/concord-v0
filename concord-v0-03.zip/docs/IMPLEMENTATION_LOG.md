# Concord Implementation Log

## Purpose

This is the chronological record of **verified implementation work** across Concord domains. It complements, rather than replaces, the current requirements in [`IAM.md`](IAM.md), [`FRONTEND.md`](FRONTEND.md), and [`HRIS.md`](HRIS.md).

### Entry rules

- Add new entries in reverse chronological order or append chronologically, but preserve every existing entry. This document uses oldest-to-newest order.
- Record the date, domain, what changed, why, and verification evidence.
- Distinguish **implemented**, **verified**, **partially implemented**, **planned**, and **blocked** work.
- Do not log a task as complete merely because code was written. Include its verification result where known.
- Do not record proposals or compatibility scaffolding as approved architecture.
- If a later entry corrects an earlier entry, retain the earlier entry and explicitly explain the correction.

## 2026-10-24 | IAM | Identity foundation and legacy schema alignment

**Status:** Implemented; verification recorded below.

### Changes

- Added the `people` table with ULID identity, split name fields, optional gender/email, and JSON preferences.
- Added a required unique `users.person_id` relationship to separate a human identity from the login account and enforce at most one linked account per person.
- Migrated user display identity into `people` and removed duplicate `email` and `display_name` columns from `users`.
- Added non-exclusive person types: employee, student, parent/guardian, and visitor.
- Added student identity and school-year enrollment history storage. Guardian import data can be retained without automatically creating parent accounts or relationships.
- Added Administrator account creation that creates a person and linked user atomically and returns the initial password once.
- Added a separate person-creation service and service-level account provisioning path for HRIS-supplied identities.
- Updated authentication payloads and frontend profile identity access to use `user.person`; removed placeholder personal/employment data that IAM does not own.
- Added persistence for personal preferences on `people` and session-warning settings on `users`, connecting existing frontend preference controls to the APIs.
- Added Administrator user listing, account deactivation, account disabling, and student enrollment history endpoints.
- Updated seeders and feature tests for person-linked accounts and sample identity categories.
- Aligned the audit logger with the current `audit_logs` schema by removing the legacy `office_id` insert/argument.
- Updated JSON test assertions to decode JSON instead of comparing serialization whitespace.
- Removed legacy access-model tables from the fresh identity-foundation schema, including tables associated with apps, offices, memberships, grants, blocks, and app groups.

### Verification

- A fresh migration was run in the Docker `iam` service and completed successfully. This is a historical event; do not rerun destructive `migrate:fresh` without explicitly checking with the user and confirming the target environment.
- Latest recorded PHPUnit result: **16 tests passed, 98 assertions**.
- Covered groups included `IamAuthTest` (6 tests), `IdentityFoundationTest` (5 tests), `UserCreationTest` (1 test), `UserManagementTest` (3 tests), and the example unit test (1 test).
- The covered behaviors included login and `/me`, equivalent wrong-password/unknown-user behavior, disabled-account login denial, session revocation, identity headers, edge caller verification, person/user separation, provisioning a person without an account and later linking an account, preference ownership, student identity/enrollment separation, Administrator account management authorization, and conflict behavior for already-disabled accounts.

### Important qualifications

- `AccessService` was added/adjusted as a **minimal compatibility implementation** after the old implementation was found to rely on legacy tables that were removed. Its current behavior caches a result, reports `all_access` for an IT admin, and returns empty `apps` and `offices` arrays. This is temporary compatibility behavior, **not** the approved final permissions architecture.
- `is_it_admin` remains transitional while the Administrator and role/permission design is undecided.
- The earlier `IAM.md` verification paragraph said PHPUnit could not start because the available local PHP runtime lacked extensions/database drivers. The later Docker-based run above supersedes that statement for the tested suite. The old local-environment limitation should be preserved only as historical context if it is still relevant, not as the current test result.
- An earlier frontend production build attempt was blocked by an archived `node_modules` package missing a platform-specific Rolldown native binding. This log does not claim that a later production build passed.

### Files / areas affected

- IAM migrations and database schema.
- IAM identity, provisioning, authentication, account-management, audit, and access compatibility code.
- IAM feature tests and seeders.
- Concord frontend profile identity and preference integration.

Exact individual file paths should be added to future entries when confirmed from the working repository. This entry intentionally avoids guessing paths not independently verified in this documentation pass.

## 2026-10-25 | Documentation | Split domain specifications and establish history

**Status:** Documentation draft prepared; repository application not yet verified.

- Split the source working specification into `IAM.md`, `FRONTEND.md`, and `HRIS.md` so identity requirements, UI requirements, and HR workflows each have a clear home.
- Added this chronological implementation log to record cross-domain work without overwriting historical entries.
- Updated the IAM verification status to reflect the later recorded Docker PHPUnit result of 16 tests and 98 assertions.
- Preserved unresolved decisions, including Administrator representation, final authorization architecture, account reactivation policy, CSV behavior, parent/student relationship management, HRIS integration details, and the user's reserved frontend design for switching among multiple person types/capacities.

**Verification:** Draft content prepared from the attached IAM specification and recorded implementation context. These files have not yet been copied into the user's local Concord repository, and repository-specific links/paths should be checked after placement.

## 2026-10-25 | Performance | asqueue-style image, faster login/logout

**Status:** Implemented; Docker build and Windows timings not yet run by the author of this entry.

- Brought the IAM container in line with asqueue: composer dependencies are installed into the image (`services/iam/Dockerfile`, shared base image in `infra/php`), `vendor/` is masked with a volume so it is not read through the Windows bind mount, optimized autoloader, asqueue's OPcache sizing plus realpath cache. JIT left off (measured slower).
- `POST /api/iam/login` now returns `user` + `access` (same payload as `/me`); the frontend signs in with one request instead of two.
- `SessionService::revoke()` takes an optional plain token so logout skips a SELECT; the token hash is part of the UPDATE's WHERE clause and the old lookup remains the fallback.
- MySQL `--skip-name-resolve`; optional `scripts/optimize.sh on|off` for Laravel caches; `scripts/bench.sh` for before/after timings.
- Unchanged by design: bcrypt 12 rounds, synchronous audit insert, session model, edge `auth_request`.

**Verification:** `php artisan test` 19 tests / 121 assertions pass against MySQL (16 existing + 3 new: login payload equals `/me`, logout revokes immediately even when cached, mismatched token never revokes the wrong session). Frontend `tsc -b` and `vite build` pass; ESLint reports the same 3 errors as before the change (none new). End-to-end timings through nginx + php-fpm + MySQL + Redis on a Linux filesystem are in `docs/PERFORMANCE.md`.

