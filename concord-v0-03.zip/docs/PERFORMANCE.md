# Concord performance: login, logout, /me

## Why it was slow

Measured with the Windows bind mount vs the Ubuntu (WSL) filesystem: walking `vendor/` took
**~28 s vs 0.179 s** (~156x). PHP loads hundreds of files per request, so every request paid
for that. asqueue avoids most of it; the first Concord scaffold did not copy that part.

## What asqueue does that makes it fast, and where Concord stands now

| asqueue (`asq-*-service`) | Concord now |
|---|---|
| `composer install` runs **inside the image build**, so `vendor/` is in the image | `services/iam/Dockerfile` does the same (dependency layer cached by `composer.lock`) |
| compose mounts the source but masks `vendor/` with `- /var/www/html/vendor`, so PHP reads vendor from the Linux side | `docker-compose.yml`: `- /var/www/vendor` on the `iam` service |
| `composer dump-autoload --optimize` | same, in the IAM Dockerfile |
| tuned OPcache (256M, 30000 files, 16M strings) | same values in `infra/php/php.ini`, plus `realpath_cache` |
| php-fpm behind nginx, FastCGI straight to port 9000, nginx only gets `public/` | unchanged (edge already works this way) |
| JIT on (`jit=1255`) | **off** by default: measured ~2 ms slower on these short requests. Two commented lines in `php.ini` turn it on |
| supervisord (queue workers, scheduler) | not needed yet (no jobs); not a speed factor |

Kept from Concord (nothing was removed): opaque server-side sessions with immediate revocation,
audit log, edge `auth_request` -> `/verify`, one shared PHP base image, account states
(active / deactivated / disabled), rate limiting at the edge and in Laravel.

## Extra optimizations (beyond asqueue)

1. **Login returns the same payload as `/me`** (`user` + `access`). The frontend no longer
   makes a second request after signing in, which removes one whole PHP boot from every login.
   The response is a superset of the old `{ "user": ... }`, so nothing that read it breaks.
2. **Logout skips a SELECT.** It already holds the session token, so it hashes it directly.
   The token hash is part of the UPDATE's WHERE clause: a wrong token can never revoke the
   wrong row, and the old lookup path still runs as a fallback. Immediate revocation is
   covered by tests.
3. **MySQL `--skip-name-resolve`**: no reverse-DNS lookup on every new connection (PHP opens
   one per request). Safe: all grants are `'user'@'%'`.
4. **Optional Laravel caches** (`./scripts/optimize.sh on|off`): config, routes, events and
   views are cached so far fewer files are read per request. Off by default so you are never
   bitten by a stale route or config while developing.

Deliberately NOT changed: bcrypt stays at 12 rounds (~250 ms of every login is the password
check, on purpose), the audit insert stays synchronous (durable), and `/me` is not cached
again (it is 4 indexed queries + two Redis reads; extra caching would add invalidation risk
for ~2 ms).

## What I measured (Linux, not your machine)

nginx (the real edge config) -> php-fpm 8.3 -> MySQL -> Redis, all on a normal Linux
filesystem, median of 24-30 runs per column:

| | v02 | new |
|---|---|---|
| login | 256 ms | 257 ms |
| /me | 13.7 ms | 12.6 ms |
| logout | 11.8 ms | 10.6 ms |
| **sign-in as the browser sees it** (login + /me before, login only now) | **269-276 ms** | **257 ms** |

Files touched under the project folder per warm `/me` request (strace):

| | per request |
|---|---|
| v02: everything, including `vendor/`, on the mount | 212 (166 in `vendor/`) |
| new: `vendor/` served from the image | 45 cross the mount |
| new + `optimize on` | 16 cross the mount |

On a fast filesystem the app was already quick (login is ~all bcrypt). The big win is on your
Windows setup, where each of those file accesses is expensive. I could not run Docker or a
Windows mount here, so **the real before/after numbers have to come from your machine**:
run `./scripts/bench.sh` before and after applying this.

## Apply it

```bash
docker compose build php-base                 # shared base image (new step)
docker compose build iam                      # installs composer deps INTO the image
docker compose up -d --build -V iam           # -V: recreate the vendor volume from the new image
cd services/concord-frontend && npm run build # login flow changed, so rebuild dist (edge serves dist/)
./scripts/bench.sh                            # numbers to compare
```

Things to know:

- **After changing `composer.json` / `composer.lock`** rebuild with `docker compose up -d --build -V iam`.
  Without `-V` the old vendor volume is reused and your new packages will be missing.
- To add a package: `docker compose exec iam composer require vendor/package`, then rebuild as above.
- The host `services/iam/vendor/` folder is no longer used by Docker (it is hidden by the volume).
  It is only there for your editor; you can delete it.
- Even with `vendor/` fixed, the rest of the code (`app/`, `config/`, `bootstrap/`, ...) is still read
  through the Windows mount. If it is still not fast enough, keep the repo inside WSL2
  (`~/concord-v0`, run Docker from there) and everything is on the Linux filesystem.
- Production: `opcache.validate_timestamps = 0`, bake code into the image (no source mount),
  `optimize on`, and drop the MySQL port mapping.
