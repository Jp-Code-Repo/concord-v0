<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;

class AccessService
{
    private const TTL = 300;

    /**
     * Clear cached access data for a user.
     */
    public function forget(string $userId): void
    {
        Cache::forget("access:{$userId}");
        Cache::forget("access:{$userId}:it-admin");
    }

    /**
     * Return the current access response for a user.
     *
     * This is a compatibility response only. The final
     * roles and permissions architecture remains undecided.
     */
    public function forUser(string $userId, bool $isItAdmin): array
    {
        $cacheKey = $isItAdmin
            ? "access:{$userId}:it-admin"
            : "access:{$userId}";

        return Cache::remember(
            $cacheKey,
            self::TTL,
            fn (): array => [
                'all_access' => $isItAdmin,
                'apps' => [],
                'offices' => [],
            ],
        );
    }
}