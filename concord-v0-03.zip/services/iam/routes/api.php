<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\Admin\StudentEnrollmentController;
use App\Http\Controllers\Admin\UserCreationController;
use App\Http\Controllers\UserManagementController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Final URLs are /api/iam/... (Laravel adds the /api prefix).
Route::prefix('iam')->group(function () {
    Route::post('login', [AuthController::class, 'login'])
        ->middleware('throttle:10,1');

    Route::middleware('session.auth')->group(function () {
        Route::post('logout', [AuthController::class, 'logout']);
        Route::get('me', [AuthController::class, 'me']);
        Route::patch('me/preferences', [AuthController::class, 'updatePreferences']);
        Route::patch('me/settings', [AuthController::class, 'updateSettings']);
        Route::get('verify', [AuthController::class, 'verify']);
        Route::post('users/{user}/deactivate', [UserManagementController::class, 'deactivate']);
        Route::post('users/{user}/disable', [UserManagementController::class, 'disable']);
    });

    Route::prefix('admin')->middleware(['session.auth', 'it.admin'])->group(function () {
        Route::get('users', [UserCreationController::class, 'index']);
        Route::post('users', [UserCreationController::class, 'store']);
        Route::get('students/{studentId}/enrollments', [StudentEnrollmentController::class, 'index']);
        Route::post('students/{studentId}/enrollments', [StudentEnrollmentController::class, 'store']);
    });

    Route::get('edge-check', function (Request $request) {
        $userId = $request->server('CONCORD_USER_ID');

        return $userId
            ? response()->json(['user_id' => $userId])
            : response()->json(['message' => 'No identity from the edge.'], 401);
    });
});
